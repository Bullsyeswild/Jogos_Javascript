let carro;
let carro2;
let carro3;
let vaca;
let rua;

function preload(){
  rua = loadImage("imagens/estrada.png");
  vaca = loadImage("imagens/ator-1.png");
  carro = loadImage("imagens/carro-1.png");
  carro2 = loadImage("imagens/carro-2.png");
  carro3 = loadImage("imagens/carro-3.png");
  imagemcarros = [carro, carro2, carro3, carro, carro2, carro3];
}